package com.project1.shoestore

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import com.project1.shoestore.databinding.FragmentShoeListBinding
import com.project1.shoestore.databinding.ShoeDesignBinding
import com.project1.shoestore.models.ShoeViewModel

class ShoeList : Fragment() {

    private lateinit var binding: FragmentShoeListBinding
    private lateinit var viewModel: ShoeViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?): View {
        binding = FragmentShoeListBinding.inflate(layoutInflater, container, false)

        binding.fab.setOnClickListener {
            view?.let { it1 -> Navigation.findNavController(it1).navigate(R.id.action_shoeList_to_shoeDetail) }

        }
        setHasOptionsMenu(true)
        viewModel = ViewModelProvider(requireActivity()).get(ShoeViewModel::class.java)
        addProduct()
        return binding.root
    }

    private fun addProduct(){

        viewModel.shoelist.observe(requireActivity(), Observer {
            viewModel.shoelist.value?.forEach {
                val bind:ShoeDesignBinding = ShoeDesignBinding.inflate(layoutInflater)
                bind.shoe = it
                //bind.root.marginTop.and(10)
                binding.showProduct.addView(bind.root)
            }
        })
   }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.menu,menu)

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        requireView().findNavController().navigate(ShoeListDirections.actionShoeListPopIncludingLogin())
        return true
    }
}

