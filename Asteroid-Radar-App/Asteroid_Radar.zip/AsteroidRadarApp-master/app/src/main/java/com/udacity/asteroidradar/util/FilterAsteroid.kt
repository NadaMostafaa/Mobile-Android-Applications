package com.udacity.asteroidradar.util

enum class FilterAsteroid {
    TODAY,
    WEEK,
    ALL
}